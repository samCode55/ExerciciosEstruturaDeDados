#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/*
Exercício 6 – Manipulação de Strings

Escreva um programa que leia o nome completo de uma pessoa utilizando fgets().

Em seguida, informe:

    quantidade de caracteres (strlen());
    quantidade de vogais;
    quantidade de consoantes;
    quantidade de espaços em branco.
*/

int main() {

    char nome[100];

    printf("DIGITE SEU NOME COMPLETO: "); 
    fgets(nome, 100, stdin); 

    int tamanho = strlen(nome);

    int vogais = 0;
    int consoantes = 0; 
    int espacos = 0;

    /*
    admito que essa merda eu realmente não soube fazer sozinho. 
    mas te garanto que eu nunca faria algo 100% IA
    (e eu acho que nunca ensinaram isso aí p nois na vdd)
    */
    for (int i = 0; i < tamanho; i++) {

        char caractere = tolower(nome[i]);

        if (caractere == 'a' ||
            caractere == 'e' ||
            caractere == 'i' ||
            caractere == 'o' ||
            caractere == 'u') {
            
            vogais++;
            }
        
        else if (caractere == ' ') {
            espacos++;
        }

        else {
            consoantes++;
        }

        printf("\n======================\n");
        printf("NOME: %s\n", nome);
        printf("QUANTIDADE DE CARACTERES: %d", tamanho);
        printf("QUANTIDADE DE VOGAIS: %d", vogais);
        printf("QUANTIDADE DE CONSOANTES: %d", consoantes);
        printf("QUANTIDADE DE ESPAÇOS: %d", espacos);
        printf("\n======================\n");

        return 0;
    }
}