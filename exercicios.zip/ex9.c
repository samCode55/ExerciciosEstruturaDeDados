/*
Exercício 9 – Modularizando um Programa

Escreva um programa para cadastrar as notas de uma turma utilizando um vetor.

Separe a solução nas seguintes funções:

    lerNotas();
    calcularMedia();
    encontrarMaiorNota();
    encontrarMenorNota();
    imprimirRelatorio();

A função main() deverá apenas coordenar a execução dessas funções.
*/

#include <stdio.h>
#include <stdlib.h>


//pqp trabalho do caralho em?
void lerNotas(float notas[], int tamanho);
float calcularMedia(float notas[], int tamanho);
float encontrarMaiorNota(float notas[], int tamanho);
float encontrarMenorNota(float notas[], int tamanho);
void imprimirRelatorio(float media, float maior, float menor);

int main() {

    float notas[6];

    lerNotas(notas, 6);

    float media = calcularMedia(notas, 6);
    float maior = encontrarMaiorNota(notas, 6);
    float menor = encontrarMenorNota(notas, 6);

    imprimirRelatorio(media, maior, menor);

    return 0;
}

void lerNotas(float notas[], int tamanho) {

    for (int i = 0; i < tamanho; i++) {

        printf("DIGITE A NOTA NUMERO %d: ", i + 1);
        scanf("%f", &notas[i]);

    }
}

float calcularMedia(float notas[], int tamanho) {

    float soma = 0;

    for (int i = 0; i < tamanho; i++) {
        soma += notas[i];
    }

    return soma / tamanho;
}

float encontrarMaiorNota(float notas[], int tamanho) {

    float maior = notas[0];

    for (int i = 1; i < tamanho; i++) {

        if (notas[i] > maior) {
            maior = notas[i];
        }

    }

    return maior;
}

float encontrarMenorNota(float notas[], int tamanho) {

    float menor = notas[0];

    for (int i = 1; i < tamanho; i++) {

        if (notas[i] < menor) {
            menor = notas[i];
        }

    }

    return menor;
}

void imprimirRelatorio(float media, float maior, float menor) {

    printf("\n===========================\n");
    printf("RELATORIO DA TURMA\n");
    printf("===========================\n");

    printf("MEDIA: %.2f\n", media);
    printf("MAIOR NOTA: %.2f\n", maior);
    printf("MENOR NOTA: %.2f\n", menor);

    printf("===========================\n");
}