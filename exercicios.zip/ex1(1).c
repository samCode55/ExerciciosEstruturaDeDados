#include <stdio.h>
#include <stdlib.h>

/*

Programa que: 

-leia 10 números inteiros e os armazene num vetor
-mostre eles na ordem digitada E INVERSA

*/

int main() {
    system("cls || clear");
    int vetor[10] = {0};

    printf("========================================\n");
        for (int i = 0; i < 10; i++) {
            printf("DIGITE O %do NUMERO: ", i + 1); scanf("%d", &vetor[i]);
        }

    printf("\n========================================\n");
    printf("ORDEM DOS NUMEROS DIGITADOS: \n");
        for (int i = 0; i < 10; i++) {
            printf("%d. %d\n", i+1, vetor[i]);            
        }
    
    printf("\n========================================\n");
    printf("ORDEM INVERSA DOS NUMEROS DIGITADOS: \n");
        for (int i = 9; i >= 1; i--) {
            printf("%d. %d\n", i+1, vetor[i]);            
        }

    return 0;
}