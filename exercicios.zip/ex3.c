#include <stdio.h>
#include <stdlib.h>

/*
Exercício 3 – Busca em Vetores

Escreva um programa que:

    leia um vetor com 15 números inteiros;
    solicite ao usuário um número para pesquisa;
    informe se o número foi encontrado;
    caso exista, informe sua posição no vetor.
*/

int main() {
    system("cls || clear");

    int vetor[15] = {0};

    printf("===========================\n");

    for (int i = 0; i < 15; i++) {
        printf("DIGITE O %do NUMERO: ", i + 1); scanf("%d", &vetor[i]); 
        clearBuffer();
    }

    printf("\n===========================\n");

    int search = 0;
    int posicao = -1;
    printf("===---MENU DE PESQUISA DE NUMEROS---===\n");
    printf("\n");
    printf("DIGITE UM NUMERO PARA PESQUISA-LO NO VETOR: "); scanf("%d", &search);

    for (int i = 0; i < 15; i++) {
        if (search == vetor[i]) {
            posicao = i;
            break;
        }
    }

    if (posicao != -1) {
        printf("NUMERO ENCONTRADO. POSICAO: %d", posicao+1);
    }
    else {
        printf("NUMERO NAO ENCONTRADO.");
    }


    return 0;
}