/*
Exercício 2 – Estatísticas de um Vetor

Escreva um programa que leia 20 números inteiros e determine:

    o maior valor;
    o menor valor;
    a média dos elementos;
    a quantidade de números pares;
    a quantidade de números ímpares.

Utilize um único vetor para armazenar os dados.
*/

void clearBuffer();

#include <stdio.h>
#include <stdlib.h>

int main() {

    int vetor[20] = {0};


    //INPUT DO USUÁRIO
    printf("=======================\n");
    for (int i = 0; i < 20; i++) {
        printf("DIGITE O %do NUMERO: ", i+1); scanf("%d", &vetor[i]);
    }
    printf("\n=======================\n");
    

    //COMPARAÇÃO DE NÚMEROS PRA DETERMINAR O MAIOR
    int maior = vetor[0];
    for (int i = 1; i < 20; i++) {
        if (vetor[i] > maior) {
            maior = vetor[i];
        }
    }
    printf("MAIOR NUMERO: %d\n", maior);

    printf("\n===========================\n");


    //COMPARAÇÃO DE NÚMEROS PRA DETERMINAR O MENOR
    int menor = vetor[0];
    for (int i = 1; i < 20; i++) {
        if (vetor[i] < menor) {
            menor = vetor[i];
        }
    }
    printf("MENOR NUMERO: %d\n", menor);

    
    //MÉDIA
    int soma = 0;

    for (int i = 0; i < 20; i++) {
        soma += vetor[i];
    }

    float media = (float)soma / 20;

    printf("MEDIA: %.3f", media);

    printf("\n================================\n");


    //PAR E IMPAR
    int pares = 0;
    int impares = 0;

    for (int i = 0; i < 20; i++) {
        if (vetor[i] % 2 == 0) {
            pares++;
        }

        else { //se nao for um é outro né
            impares++;
        }
    }


    printf("NUMEROS PARES: %d\nNUMEROS IMPARES: %d", pares, impares);
    printf("\n===============================\n");


    return 0;
}

void clearBuffer() {
    while(getchar() != '\n');
}