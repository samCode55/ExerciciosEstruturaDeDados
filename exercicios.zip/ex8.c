/*
Exercício 8 – Funções

Implemente as seguintes funções:

int maior(int a, int b);

int menor(int a, int b);

float media(float a, float b);

int fatorial(int n);

Em seguida, desenvolva um programa que utilize todas essas funções.
*/

#include <stdio.h>
#include <stdlib.h>

int maior(int a, int b);
int menor(int a, int b);
float media(float a, float b);
int fatorial(int n);

int main() {

    int a, b, numero;

    printf("===========================\n");

    printf("DIGITE O PRIMEIRO NUMERO: ");
    scanf("%d", &a);

    printf("DIGITE O SEGUNDO NUMERO: ");
    scanf("%d", &b);

    printf("DIGITE UM NUMERO PARA CALCULAR O FATORIAL: ");
    scanf("%d", &numero);

    printf("\n===========================\n");

    printf("MAIOR NUMERO: %d\n", maior(a, b));
    printf("MENOR NUMERO: %d\n", menor(a, b));
    printf("MEDIA: %.2f\n", media(a, b));
    printf("FATORIAL DE %d: %d\n", numero, fatorial(numero));

    printf("===========================\n");

    return 0;
}

int maior(int a, int b) {

    if (a > b) {
        return a;
    } else {
        return b;
    }
}

int menor(int a, int b) {

    if (a < b) {
        return a;
    } else {
        return b;
    }
}

float media(float a, float b) {

    return (a + b) / 2;
}

int fatorial(int n) {

    int resultado = 1;

    for (int i = 1; i <= n; i++) {
        resultado *= i;
    }

    return resultado;
}